﻿using Microsoft.AspNetCore.Mvc.Testing;
using System.Net;

public class IntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public IntegrationTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetIntervals_ShouldReturn200()
    {
        var response = await _client.GetAsync("/api/producers/intervals");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var content = await response.Content.ReadAsStringAsync();
        Assert.Contains("min", content);
        Assert.Contains("max", content);
    }
}
