﻿using GoldenRaspberryAwards.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace GoldenRaspberryAwards.Api.Controllers
{
    [ApiController]
    [Route("api/producers")]
    public class ProducerController : ControllerBase
    {
        private readonly IntervalService _service;

        public ProducerController(IntervalService service) => _service = service;

        [HttpGet("intervals")]
        public IActionResult Get() => Ok(_service.Calculate());
    }
}
