using GoldenRaspberryAwards.Api.Data;
using GoldenRaspberryAwards.Api.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// EF Core InMemory
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("GoldenRaspberryDb"));

// Servi�os de dom�nio
builder.Services.AddScoped<IntervalService>();
builder.Services.AddScoped<CsvLoader>();

var app = builder.Build();

// Carrega o CSV no startup
using (var scope = app.Services.CreateScope())
{
    var loader = scope.ServiceProvider.GetRequiredService<CsvLoader>();
    loader.Load(Path.Combine(app.Environment.ContentRootPath, "Resources", "movielist.csv"));
}

app.UseHttpsRedirection();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();
app.Run();
public partial class Program { }

