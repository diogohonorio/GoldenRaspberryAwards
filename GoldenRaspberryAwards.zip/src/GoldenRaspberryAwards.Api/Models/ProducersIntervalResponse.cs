﻿namespace GoldenRaspberryAwards.Api.Models
{
    public class ProducersIntervalResponse
    {
        public List<AwardInterval> Min { get; set; } = new();
        public List<AwardInterval> Max { get; set; } = new();
    }
}
