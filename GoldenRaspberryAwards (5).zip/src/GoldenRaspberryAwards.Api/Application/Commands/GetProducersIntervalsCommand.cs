﻿namespace GoldenRaspberryAwards.Api.Application.Commands
{
    public class GetProducersIntervalsCommand
    {
    }
}
