﻿using GoldenRaspberryAwards.Api.Application.Commands;
using Microsoft.AspNetCore.Mvc.Testing;
using System.Net;
using System.Text.Json;

public class IntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;

    public IntegrationTests(WebApplicationFactory<Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetIntervals_ShouldReturn200()
    {
        var response = await _client.GetAsync("/api/producers/intervals");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var content = await response.Content.ReadAsStringAsync();
        Assert.Contains("min", content);
        Assert.Contains("max", content);
    }

    [Fact]
    public async Task GetIntervals_ShouldReturnMinAndMax()
    {
        var response = await _client.GetAsync("/api/producers/intervals");
        response.EnsureSuccessStatusCode();

        var content = await response.Content.ReadAsStringAsync();
        var result = JsonSerializer.Deserialize<ProducersIntervalResponse>(content, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        Assert.NotNull(result);
        Assert.NotNull(result.Min);
        Assert.NotNull(result.Max);
    }
}
